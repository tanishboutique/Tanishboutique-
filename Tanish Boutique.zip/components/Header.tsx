
import React, { useState, useRef, useEffect } from 'react';
import { ShoppingBag, Ruler, Sparkles, User, Menu, X, Phone, Home, Package, Search } from 'lucide-react';
import { View } from '../types';

interface HeaderProps {
  currentView: View;
  onNavigate: (view: View) => void;
  cartCount: number;
  onOpenCart: () => void;
  searchQuery: string;
  onSearch: (query: string) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, cartCount, onOpenCart, searchQuery, onSearch }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchVisible && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchVisible]);

  const navLinks = [
    { name: 'HOME', view: View.Home, icon: <Home size={16} /> },
    { name: 'COLLECTIONS', view: View.Shop, icon: <Package size={16} /> },
    { name: 'MEASUREMENTS', view: View.Measurements, icon: <Ruler size={16} /> },
    { name: 'BOOK APPOINTMENT', view: View.Booking, icon: <Package size={16} /> },
    { name: 'AI STYLIST', view: View.Stylist, icon: <Sparkles size={16} className="text-pink-500" /> },
    { name: 'ACCOUNT', view: View.Account, icon: <User size={16} /> },
  ];

  const handleMobileNav = (view: View) => {
    onNavigate(view);
    setIsMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#fcfbf7]/90 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex flex-col items-center cursor-pointer" onClick={() => onNavigate(View.Home)}>
            <h1 className="text-xl md:text-2xl tracking-[0.2em] font-bold text-pink-700 leading-none text-center">TANISH</h1>
            <span className="text-[8px] tracking-[0.4em] text-stone-400 uppercase mt-1">BOUTIQUE</span>
          </div>
          
          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navLinks.filter(l => l.view !== View.Home && l.view !== View.Account).map((link) => (
              <button 
                key={link.name}
                onClick={() => onNavigate(link.view)}
                className={`text-[10px] tracking-[0.2em] hover:text-pink-600 transition-colors uppercase flex items-center gap-1 ${currentView === link.view ? 'text-pink-700 font-bold' : 'text-stone-600'}`}
              >
                {link.name === 'AI STYLIST' || link.name === 'MEASUREMENTS' ? link.icon : null}
                {link.name}
              </button>
            ))}
          </nav>

          {/* Action Icons */}
          <div className="flex items-center space-x-3 md:space-x-5">
            {/* Desktop Search */}
            <div className={`hidden md:flex items-center transition-all duration-300 ${isSearchVisible ? 'w-48' : 'w-10'}`}>
              {isSearchVisible ? (
                <div className="relative flex items-center w-full bg-stone-100 rounded-full px-3 py-1.5 border border-stone-200 animate-in fade-in slide-in-from-right-2">
                  <Search size={14} className="text-stone-400 mr-2 flex-shrink-0" />
                  <input
                    ref={searchInputRef}
                    type="text"
                    placeholder="Search catalog..."
                    value={searchQuery}
                    onChange={(e) => onSearch(e.target.value)}
                    onBlur={() => !searchQuery && setIsSearchVisible(false)}
                    className="w-full bg-transparent border-none outline-none text-[10px] uppercase tracking-wider text-stone-900 placeholder:text-stone-300"
                  />
                  {searchQuery && (
                    <button onClick={() => onSearch('')} className="ml-1 text-stone-400 hover:text-pink-600">
                      <X size={12} />
                    </button>
                  )}
                </div>
              ) : (
                <button 
                  onClick={() => setIsSearchVisible(true)}
                  className="p-2 text-stone-600 hover:text-pink-600 transition-colors"
                  aria-label="Search items"
                >
                  <Search size={20} />
                </button>
              )}
            </div>

            <a href="tel:+919878789036" className="hidden sm:flex items-center gap-2 text-[10px] font-bold text-pink-700 hover:text-pink-800 transition-colors tracking-widest bg-pink-50 px-3 py-2 rounded-full border border-pink-100">
              CALL US
            </a>
            
            <button 
              onClick={() => onNavigate(View.Account)}
              className={`hover:text-pink-600 transition-colors hidden lg:block ${currentView === View.Account ? 'text-pink-700' : 'text-stone-600'}`}
            >
              <User size={20} />
            </button>

            <button 
              onClick={onOpenCart}
              className="text-stone-600 hover:text-pink-600 relative p-1"
            >
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-pink-600 text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="lg:hidden text-stone-600 hover:text-pink-600 p-1"
              aria-label="Open menu"
            >
              <Menu size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <div 
        className={`fixed inset-0 z-[60] lg:hidden transition-opacity duration-300 ${isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
      >
        {/* Backdrop */}
        <div 
          className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm"
          onClick={() => setIsMenuOpen(false)}
        />

        {/* Drawer Panel */}
        <div 
          className={`absolute top-0 right-0 w-80 h-full bg-white shadow-2xl transition-transform duration-300 ease-in-out transform flex flex-col ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}
        >
          <div className="p-6 flex justify-between items-center border-b border-stone-100">
            <div className="flex flex-col">
              <h2 className="text-lg tracking-widest font-bold text-pink-700 leading-none">TANISH</h2>
              <span className="text-[8px] tracking-[0.4em] text-stone-400 uppercase mt-1">MENU</span>
            </div>
            <button 
              onClick={() => setIsMenuOpen(false)}
              className="p-2 text-stone-400 hover:text-pink-600 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6">
            <div className="relative flex items-center w-full bg-stone-50 rounded-lg px-4 py-3 border border-stone-100">
              <Search size={16} className="text-stone-400 mr-3" />
              <input
                type="text"
                placeholder="Search collection..."
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
                className="w-full bg-transparent border-none outline-none text-xs font-medium tracking-wider text-stone-900 placeholder:text-stone-300"
              />
              {searchQuery && (
                <button onClick={() => onSearch('')} className="text-stone-300">
                  <X size={16} />
                </button>
              )}
            </div>
          </div>

          <nav className="flex-1 py-4 px-6 space-y-2 overflow-y-auto">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => handleMobileNav(link.view)}
                className={`w-full flex items-center space-x-4 py-4 px-4 rounded-lg transition-all duration-200 group ${currentView === link.view ? 'bg-pink-50 text-pink-700' : 'text-stone-600 hover:bg-stone-50'}`}
              >
                <span className={`${currentView === link.view ? 'text-pink-600' : 'text-stone-400 group-hover:text-pink-400'}`}>
                  {link.icon}
                </span>
                <span className="text-xs font-bold tracking-[0.2em] uppercase">{link.name}</span>
              </button>
            ))}
          </nav>

          <div className="p-6 border-t border-stone-100 bg-stone-50 space-y-4">
            <a 
              href="tel:+919878789036"
              className="flex items-center justify-center gap-3 w-full py-4 bg-pink-600 text-white rounded-lg text-xs font-bold tracking-widest uppercase hover:bg-pink-700 transition-colors shadow-lg shadow-pink-200"
            >
              <Phone size={16} />
              Call Now: +91 9878789036
            </a>
            <p className="text-[9px] text-stone-400 text-center uppercase tracking-widest leading-relaxed">
              Visit us: Shop No. 75, Sidhu Estate<br/>Dakoha, Jalandhar
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
