
import React, { useState } from 'react';
import { SERVICES } from '../constants';
import { BookingService } from '../types';
import { CheckCircle, MapPin, Smartphone } from 'lucide-react';

const BookingCalendar: React.FC = () => {
  const [selectedService, setSelectedService] = useState<BookingService | null>(null);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [isBooked, setIsBooked] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedService && date && time) {
      setIsBooked(true);
      
      // Construct WhatsApp Message
      let message = `Hello Munna (Samsul Hoda)! 🧵 I'd like to book an appointment at Tanish Boutique.\n\n`;
      message += `*Service:* ${selectedService.name}\n`;
      message += `*Date:* ${date}\n`;
      message += `*Preferred Time:* ${time}\n\n`;
      message += `Looking forward to seeing you at the studio! ✨`;

      const encodedMessage = encodeURIComponent(message);
      
      // Short delay for visual feedback before redirect
      setTimeout(() => {
        window.open(`https://wa.me/919878789036?text=${encodedMessage}`, '_blank');
      }, 2000);

      setTimeout(() => setIsBooked(false), 8000);
    }
  };

  if (isBooked) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4 animate-in fade-in duration-500">
        <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center text-green-600 mb-4">
          <CheckCircle size={40} />
        </div>
        <h2 className="text-3xl font-light serif italic">Session Request Sent</h2>
        <p className="text-stone-500 max-w-md">We are redirecting you to WhatsApp to finalize your visit with Munna. Please wait a moment...</p>
        <div className="flex items-center gap-2 text-pink-600 animate-pulse font-black text-[10px] uppercase tracking-widest mt-4">
           <Smartphone size={16} /> Opening WhatsApp...
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-12 px-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-light serif italic mb-4">Reserve Your Experience</h2>
        <p className="text-stone-500 font-light max-w-xl mx-auto mb-6">Luxury is personal. Book a private session with our stylists or find the perfect fit with our in-house alterations.</p>
        <div className="flex items-center justify-center gap-2 text-stone-400 text-xs tracking-widest uppercase font-bold">
          <MapPin size={14} className="text-pink-600" />
          <span>Shop No. 75, Sidhu Estate, Talhan Road, Jalandhar</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h3 className="text-xl serif italic font-bold text-stone-900 border-l-4 border-pink-600 pl-4">1. Select a Service</h3>
          <div className="space-y-4">
            {SERVICES.map((service) => (
              <div 
                key={service.id}
                onClick={() => setSelectedService(service)}
                className={`p-6 border rounded-xl cursor-pointer transition-all duration-300 ${selectedService?.id === service.id ? 'border-pink-600 bg-pink-50 ring-2 ring-pink-100 shadow-md' : 'border-stone-200 hover:border-pink-200 bg-white hover:shadow-sm'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-black text-stone-900 uppercase tracking-widest text-xs">{service.name}</span>
                  <span className="text-pink-600 font-black text-xs">{service.price}</span>
                </div>
                <p className="text-stone-500 text-[10px] mb-3 leading-relaxed">{service.description}</p>
                <span className="text-[10px] bg-white px-2 py-1 rounded border border-stone-100 font-black text-stone-400 uppercase tracking-tighter">{service.duration} Session</span>
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <h3 className="text-xl serif italic font-bold text-stone-900 border-l-4 border-pink-600 pl-4">2. Schedule Time</h3>
          <div className="space-y-4 bg-white p-8 rounded-2xl border border-stone-100 shadow-sm">
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Select Date</label>
              <input 
                type="date" 
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-4 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 font-bold transition-all"
              />
            </div>
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Select Time Slot</label>
              <select 
                required
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full p-4 border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 bg-white font-bold transition-all cursor-pointer"
              >
                <option value="">Choose a slot</option>
                <option value="10:00 AM">10:00 AM</option>
                <option value="11:30 AM">11:30 AM</option>
                <option value="01:00 PM">01:00 PM</option>
                <option value="02:30 PM">02:30 PM</option>
                <option value="04:00 PM">04:00 PM</option>
                <option value="05:30 PM">05:30 PM</option>
              </select>
            </div>
            <div className="pt-6">
              <button 
                type="submit"
                disabled={!selectedService}
                className={`w-full py-5 rounded-lg uppercase tracking-widest text-[10px] font-black transition-all duration-300 shadow-lg ${selectedService ? 'bg-stone-900 text-white hover:bg-pink-700 hover:shadow-pink-200' : 'bg-stone-100 text-stone-400 cursor-not-allowed'}`}
              >
                Confirm via WhatsApp
              </button>
              <p className="text-[9px] text-stone-400 mt-4 text-center uppercase tracking-widest leading-relaxed">
                By clicking confirm, we will start a WhatsApp chat with<br/>Samsul Hoda to finalize your appointment.
              </p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookingCalendar;
