
import React, { useState } from 'react';
import { Order, View } from '../types';
import { Package, ChevronRight, MapPin, Phone, User as UserIcon, Clock, CreditCard, Wallet } from 'lucide-react';

interface AccountProps {
  orders: Order[];
  onNavigate: (view: View) => void;
}

const Account: React.FC<AccountProps> = ({ orders, onNavigate }) => {
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  const selectedOrder = orders.find(o => o.id === selectedOrderId);

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'Processing': return 'bg-amber-50 text-amber-600 border-amber-100';
      case 'In Stitching': return 'bg-blue-50 text-blue-600 border-blue-100';
      case 'Shipped': return 'bg-indigo-50 text-indigo-600 border-indigo-100';
      case 'Delivered': return 'bg-green-50 text-green-600 border-green-100';
      default: return 'bg-stone-50 text-stone-600 border-stone-100';
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="flex flex-col md:flex-row gap-12">
        {/* Profile Sidebar */}
        <div className="md:w-1/3 space-y-8">
          <div className="bg-white p-6 border border-stone-100 rounded-lg shadow-sm">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center text-pink-600">
                <UserIcon size={32} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-stone-900 serif italic">Aman Kaur</h2>
                <p className="text-xs text-stone-400 uppercase tracking-widest">Premium Member</p>
              </div>
            </div>
            
            <div className="space-y-4 pt-4 border-t border-stone-50">
              <div className="flex items-center gap-3 text-stone-600 text-sm">
                <Phone size={14} className="text-stone-400" /> +91 98XXX XXXXX
              </div>
              <div className="flex items-center gap-3 text-stone-600 text-sm">
                <MapPin size={14} className="text-stone-400" /> Jalandhar, Punjab
              </div>
            </div>

            <button 
              onClick={() => onNavigate(View.Measurements)}
              className="w-full mt-8 py-3 border border-stone-200 text-stone-600 text-[10px] tracking-widest uppercase hover:bg-stone-50 transition-colors rounded-sm"
            >
              Update Measurements
            </button>
          </div>
        </div>

        {/* Order History Main Content */}
        <div className="md:w-2/3">
          <h2 className="text-3xl font-light serif italic mb-8 flex items-center gap-3">
            <Package className="text-pink-600" /> Order History
          </h2>

          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="bg-white border border-stone-100 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <div 
                  className="p-6 flex items-center justify-between cursor-pointer"
                  onClick={() => setSelectedOrderId(selectedOrderId === order.id ? null : order.id)}
                >
                  <div className="space-y-1">
                    <p className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">{order.id}</p>
                    <p className="text-sm font-semibold text-stone-900">{new Date(order.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                    <div className="flex flex-wrap items-center gap-2 mt-2">
                      <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border ${getStatusColor(order.status)}`}>
                        {order.status}
                      </span>
                      <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full border bg-pink-50 text-pink-600 border-pink-100`}>
                        {order.paymentType}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-pink-700">₹{order.total}</p>
                    <button className="text-stone-300 hover:text-pink-600 transition-colors mt-2">
                      <ChevronRight size={20} className={`transform transition-transform ${selectedOrderId === order.id ? 'rotate-90' : ''}`} />
                    </button>
                  </div>
                </div>

                {selectedOrderId === order.id && (
                  <div className="px-6 pb-6 pt-2 border-t border-stone-50 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="bg-stone-50 p-4 rounded-xl mb-6 space-y-2">
                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                        <span className="text-stone-400 flex items-center gap-2"><CreditCard size={12}/> Amount Paid</span>
                        <span className="text-stone-900">₹{order.amountPaid}</span>
                      </div>
                      {order.paymentType === '50% Advance' && (
                        <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest pt-2 border-t border-stone-100">
                          <span className="text-pink-400 flex items-center gap-2"><Wallet size={12}/> Balance Due</span>
                          <span className="text-pink-600">₹{order.total - order.amountPaid}</span>
                        </div>
                      )}
                    </div>

                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-stone-400 mb-4">Items Ordered</h4>
                    <div className="space-y-3">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between items-center text-sm">
                          <div className="flex flex-col">
                            <span className="text-stone-600 font-medium">{item.name} <span className="text-stone-300 text-xs">x{item.quantity}</span></span>
                            {item.selectedLace && (
                              <span className="text-[9px] text-pink-400 uppercase font-black">Lace: {item.selectedLace.name} ({item.laceMeters}m)</span>
                            )}
                          </div>
                          <span className="font-semibold text-stone-800">₹{item.price * item.quantity + ((item.laceMeters || 0) * (item.selectedLace?.price || 0))}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-6 pt-4 border-t border-stone-50 flex justify-between items-center">
                      <div className="flex items-center gap-2 text-stone-400 text-xs italic">
                        <Clock size={12} /> Target: Mar 25, 2024
                      </div>
                      <button className="text-[10px] font-bold text-pink-600 hover:underline uppercase tracking-widest">
                        Download Invoice
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {orders.length === 0 && (
              <div className="py-20 text-center bg-white border border-dashed border-stone-200 rounded-lg">
                <Package size={48} className="mx-auto text-stone-200 mb-4" />
                <p className="text-stone-400 italic">No past orders found.</p>
                <button 
                  onClick={() => onNavigate(View.Shop)}
                  className="mt-4 text-pink-600 font-bold uppercase tracking-widest text-[10px] hover:underline"
                >
                  Start Shopping
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
