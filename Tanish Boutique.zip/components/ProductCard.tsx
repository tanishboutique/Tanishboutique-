
import React, { useState, useEffect, useCallback } from 'react';
import { Product, Review, LaceOption } from '../types';
import { Star, MessageCircle, X, ShoppingBag, Plus, Sparkles, Scissors, Info, Check, ChevronLeft, ChevronRight, Maximize2, ZoomIn, Eye } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, laceMeters?: number, selectedLace?: LaceOption) => void;
  onAddReview: (productId: string, review: Omit<Review, 'id' | 'date'>) => void;
  quantityInCart: number;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onAddToCart, 
  onAddReview, 
  quantityInCart 
}) => {
  const [showReviews, setShowReviews] = useState(false);
  const [showLaceConfig, setShowLaceConfig] = useState(false);
  const [selectedLaceId, setSelectedLaceId] = useState<string>(product.laceOptions?.[0]?.id || '');
  const [laceMeters, setLaceMeters] = useState<number>(0);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  
  const [newReviewName, setNewReviewName] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewComment, setNewReviewComment] = useState('');

  const averageRating = product.reviews.length > 0 
    ? (product.reviews.reduce((acc, r) => acc + r.rating, 0) / product.reviews.length).toFixed(1)
    : 'New';

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (newReviewName && newReviewComment) {
      onAddReview(product.id, {
        name: newReviewName,
        rating: newReviewRating,
        comment: newReviewComment
      });
      setNewReviewName('');
      setNewReviewComment('');
      setNewReviewRating(5);
    }
  };

  const handleAddToCartClick = () => {
    const selectedLace = product.laceOptions?.find(l => l.id === selectedLaceId);
    onAddToCart(product, laceMeters, selectedLace);
    setLaceMeters(0);
    setShowLaceConfig(false);
  };

  const nextImage = useCallback((e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
  }, [product.images.length]);

  const prevImage = useCallback((e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
  }, [product.images.length]);

  // Close Lightbox on Escape
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsLightboxOpen(false);
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, []);

  const isOwnersChoice = product.category === 'Bridal' || product.price > 3000;
  const currentLace = product.laceOptions?.find(l => l.id === selectedLaceId);
  const totalLaceCost = laceMeters * (currentLace?.price || 0);

  return (
    <div 
      className="group relative flex flex-col bg-white overflow-hidden rounded-[2rem] transition-all duration-700 hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.12)] hover:-translate-y-2 border border-stone-100 h-full shadow-sm"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      
      {/* Immersive Premium Gallery Section */}
      <div className="aspect-[3/4] overflow-hidden bg-stone-100 relative group/carousel">
        {/* Story-style Progress Bars */}
        {product.images.length > 1 && (
          <div className="absolute top-3 inset-x-3 z-20 flex gap-1.5 px-1 opacity-60 hover:opacity-100 transition-opacity">
            {product.images.map((_, idx) => (
              <div 
                key={idx} 
                className={`h-1 flex-1 rounded-full transition-all duration-500 ${idx === currentImageIndex ? 'bg-white scale-y-125' : 'bg-white/30'}`}
              />
            ))}
          </div>
        )}

        <div 
          className="relative w-full h-full cursor-zoom-in"
          onClick={() => setIsLightboxOpen(true)}
        >
          <img
            key={currentImageIndex}
            src={product.images[currentImageIndex]}
            alt={`${product.name} view ${currentImageIndex + 1}`}
            className="h-full w-full object-cover object-center transition-all duration-1000 ease-out animate-in fade-in zoom-in-105"
          />
          
          {/* Quick Info & Zoom Hint */}
          <div className="absolute top-8 right-4 z-10 opacity-0 group-hover/carousel:opacity-100 transition-all translate-x-2 group-hover/carousel:translate-x-0">
            <div className="bg-white/90 backdrop-blur-md p-3 rounded-full shadow-2xl text-stone-900 border border-white/20">
               <Maximize2 size={18} />
            </div>
          </div>

          <div className="absolute bottom-6 left-6 z-10 bg-stone-900/60 backdrop-blur-lg px-3 py-1.5 rounded-full text-[9px] font-black text-white uppercase tracking-[0.2em] border border-white/10 flex items-center gap-2">
             <Eye size={12} className="text-pink-400" />
             {currentImageIndex + 1} / {product.images.length} VIEWS
          </div>
          
          {/* Refined Navigation Arrows */}
          {product.images.length > 1 && (
            <>
              <button 
                onClick={prevImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 backdrop-blur-xl text-white opacity-0 group-hover/carousel:opacity-100 transition-all hover:bg-white hover:text-stone-900 shadow-2xl hover:scale-110 active:scale-95"
              >
                <ChevronLeft size={24} />
              </button>
              <button 
                onClick={nextImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 backdrop-blur-xl text-white opacity-0 group-hover/carousel:opacity-100 transition-all hover:bg-white hover:text-stone-900 shadow-2xl hover:scale-110 active:scale-95"
              >
                <ChevronRight size={24} />
              </button>
            </>
          )}
        </div>
        
        {/* Boutique Badges */}
        <div className="absolute top-8 left-6 flex flex-col gap-2.5 z-10 pointer-events-none">
          <div className="bg-pink-600 text-white text-[10px] px-4 py-2 rounded-full font-black tracking-widest shadow-[0_10px_20px_-5px_rgba(219,39,119,0.5)] flex items-center gap-2 animate-pulse">
            <Sparkles size={12} /> ₹1000 OFF
          </div>
          {isOwnersChoice && (
            <div className="bg-stone-900/95 backdrop-blur-md text-[#D4AF37] text-[10px] px-4 py-2 rounded-full font-black tracking-widest shadow-xl flex items-center gap-2 border border-[#D4AF37]/40">
               <Star size={12} className="fill-[#D4AF37]" /> OWNER'S CHOICE
            </div>
          )}
        </div>
        
        {/* In-Cart Status */}
        {quantityInCart > 0 && (
          <div className="absolute bottom-6 right-6 bg-pink-600 text-white text-[10px] px-5 py-2.5 rounded-full font-black flex items-center gap-2 shadow-2xl z-10 border border-white/20 animate-in slide-in-from-right-4">
            <ShoppingBag size={14} className="animate-bounce" />
            <span>{quantityInCart} COLLECTED</span>
          </div>
        )}

        {/* Dynamic Action Overlay */}
        <div className="absolute inset-x-0 bottom-0 p-8 opacity-0 translate-y-6 transition-all duration-700 group-hover:opacity-100 group-hover:translate-y-0 bg-gradient-to-t from-stone-900/90 via-stone-900/40 to-transparent flex flex-col gap-4 z-10">
          {product.allowsLaces && (
            <button
              onClick={(e) => { e.stopPropagation(); setShowLaceConfig(!showLaceConfig); }}
              className="w-full bg-white/10 backdrop-blur-xl text-white border border-white/20 py-4 rounded-2xl text-[11px] tracking-[0.2em] uppercase font-black hover:bg-white hover:text-stone-900 transition-all shadow-xl flex items-center justify-center gap-3"
            >
              <Scissors size={16} /> {showLaceConfig ? 'Close Customizer' : 'Personalize Laces'}
            </button>
          )}
          <button
            onClick={(e) => { e.stopPropagation(); handleAddToCartClick(); }}
            className="w-full bg-pink-600 text-white py-4 rounded-2xl text-[11px] tracking-[0.2em] uppercase font-black hover:bg-pink-700 transition-all shadow-2xl flex items-center justify-center gap-3 active:scale-95"
          >
            <Plus size={16} /> Add to Collection
          </button>
        </div>
      </div>

      {/* Elegant Thumbnail Navigation */}
      {product.images.length > 1 && (
        <div className="px-6 py-4 flex gap-3 overflow-x-auto bg-stone-50/30 border-b border-stone-100 no-scrollbar">
          {product.images.map((img, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentImageIndex(idx)}
              className={`w-14 h-18 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-all duration-500 relative ${currentImageIndex === idx ? 'border-pink-500 scale-110 shadow-lg z-10' : 'border-transparent opacity-40 hover:opacity-100'}`}
            >
              <img src={img} className="w-full h-full object-cover" alt="" />
              {currentImageIndex === idx && (
                <div className="absolute inset-0 bg-pink-500/10 animate-pulse" />
              )}
            </button>
          ))}
        </div>
      )}

      <div className="p-8 flex flex-col flex-grow bg-white">
        {/* Lace Configuration Drawer */}
        {showLaceConfig && product.allowsLaces && (
          <div className="mb-8 p-6 bg-pink-50/50 rounded-[2rem] border border-pink-100 shadow-inner animate-in slide-in-from-top-4 duration-500">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="bg-pink-100 p-2 rounded-lg text-pink-600">
                  <Scissors size={16} />
                </div>
                <span className="text-[11px] font-black uppercase tracking-[0.2em] text-pink-800">Custom Border Menu</span>
              </div>
            </div>
            
            <div className="space-y-5">
              <div className="grid grid-cols-1 gap-3">
                {product.laceOptions?.map(lace => (
                  <button
                    key={lace.id}
                    onClick={() => setSelectedLaceId(lace.id)}
                    className={`flex items-center gap-4 p-3.5 rounded-2xl border transition-all ${selectedLaceId === lace.id ? 'border-pink-500 bg-white ring-4 ring-pink-100/50 shadow-md' : 'border-stone-100 bg-white/80 hover:bg-white hover:border-pink-200'}`}
                  >
                    <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 border border-stone-100 shadow-sm">
                      {lace.image ? (
                        <img src={lace.image} alt={lace.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-stone-100">
                          <Scissors size={16} className="text-stone-300" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-[11px] font-black text-stone-900 uppercase leading-none mb-1.5">{lace.name}</p>
                      <p className="text-[10px] font-bold text-pink-600">₹{lace.price} per meter</p>
                    </div>
                    {selectedLaceId === lace.id && (
                      <div className="w-6 h-6 bg-pink-600 rounded-full flex items-center justify-center text-white">
                        <Check size={14} />
                      </div>
                    )}
                  </button>
                ))}
              </div>
              
              <div className="flex items-center justify-between gap-6 pt-5 border-t border-pink-200/30">
                <div className="flex-1">
                  <div className="relative">
                    <input 
                      type="number" 
                      min="0"
                      step="0.5"
                      value={laceMeters || ''}
                      onChange={(e) => setLaceMeters(parseFloat(e.target.value) || 0)}
                      className="w-full bg-white border border-stone-200 p-3 text-[12px] font-black rounded-xl focus:ring-2 focus:ring-pink-500 outline-none transition-all"
                      placeholder="Meters required"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[9px] font-black text-stone-300 uppercase tracking-widest">mtrs</span>
                  </div>
                </div>
                <div className="text-right">
                   <p className="text-[9px] font-black text-stone-400 uppercase tracking-tighter mb-1">Estimated Cost</p>
                   <p className="text-lg font-black text-pink-700">₹{totalLaceCost.toFixed(0)}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Basic Product Info */}
        <div className="flex justify-between items-start mb-3">
          <p className="text-[11px] text-stone-400 font-black uppercase tracking-[0.25em]">{product.category}</p>
          <div className="flex items-center gap-1.5 bg-amber-50 px-3 py-1 rounded-full border border-amber-100">
            <Star size={12} className="text-amber-500 fill-amber-500" />
            <span className="text-[11px] font-black text-amber-700">{averageRating}</span>
          </div>
        </div>
        
        <h3 className="text-2xl font-serif italic text-stone-900 mb-3 leading-tight group-hover:text-pink-600 transition-colors">{product.name}</h3>
        <p className="text-sm text-stone-500 line-clamp-2 mb-8 font-light leading-relaxed">{product.description}</p>
        
        <div className="mt-auto flex items-center justify-between pt-6 border-t border-stone-100">
          <div className="flex flex-col">
            <span className="text-[11px] text-stone-300 font-bold uppercase tracking-[0.2em] line-through">₹{product.originalPrice}</span>
            <div className="flex items-baseline gap-1.5">
               <span className="text-sm font-black text-pink-700">₹</span>
               <span className="text-3xl font-black text-pink-700 tracking-tighter">{product.price.toLocaleString('en-IN')}</span>
            </div>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); setShowReviews(!showReviews); }}
            className="p-4 bg-stone-50 text-stone-400 hover:text-pink-600 hover:bg-pink-50 rounded-[1.5rem] transition-all flex items-center gap-3 group/review shadow-sm active:scale-95"
            title="View Feedbacks"
          >
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-black uppercase tracking-tighter text-stone-900 leading-none">{product.reviews.length} Feedbacks</span>
              <span className="text-[8px] font-bold uppercase tracking-widest text-stone-400 mt-1 hidden sm:block">View Diary</span>
            </div>
            <MessageCircle size={22} className="group-hover/review:scale-110 transition-transform" />
          </button>
        </div>
      </div>

      {/* Lightbox / Immersive Full-Screen Experience */}
      {isLightboxOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-stone-950/98 backdrop-blur-3xl animate-in fade-in duration-500">
          <button 
            onClick={() => setIsLightboxOpen(false)}
            className="absolute top-10 right-10 z-50 p-4 bg-white/5 hover:bg-white/20 text-white rounded-full transition-all border border-white/10 hover:rotate-90"
          >
            <X size={32} />
          </button>

          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 md:p-16">
            <div className="relative max-w-5xl w-full h-full flex items-center justify-center group/lightbox">
              <img 
                key={currentImageIndex}
                src={product.images[currentImageIndex]} 
                className="max-w-full max-h-[75vh] object-contain rounded-2xl shadow-[0_50px_100px_-20px_rgba(0,0,0,0.8)] border border-white/5 animate-in zoom-in-95 duration-1000"
                alt={product.name}
              />
              
              {/* Floating Designer Info */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full flex justify-between px-4 md:px-0 pointer-events-none opacity-0 group-hover/lightbox:opacity-100 transition-opacity">
                {product.images.length > 1 && (
                  <>
                    <button 
                      onClick={prevImage}
                      className="p-6 text-white/40 hover:text-white hover:scale-125 transition-all pointer-events-auto bg-black/20 backdrop-blur-md rounded-full border border-white/10"
                    >
                      <ChevronLeft size={48} />
                    </button>
                    <button 
                      onClick={nextImage}
                      className="p-6 text-white/40 hover:text-white hover:scale-125 transition-all pointer-events-auto bg-black/20 backdrop-blur-md rounded-full border border-white/10"
                    >
                      <ChevronRight size={48} />
                    </button>
                  </>
                )}
              </div>

              {/* Bottom Immersive Panel */}
              <div className="absolute -bottom-12 md:bottom-0 left-0 right-0 p-8 flex flex-col md:flex-row items-center justify-between gap-8 opacity-0 group-hover/lightbox:opacity-100 transition-opacity translate-y-4 group-hover/lightbox:translate-y-0 duration-700">
                 <div className="flex flex-col items-center md:items-start text-center md:text-left">
                    <h4 className="text-white serif italic text-3xl mb-2">{product.name}</h4>
                    <p className="text-pink-400 text-[11px] font-black uppercase tracking-[0.4em]">Signature Munna Tailoring • Est. 1994</p>
                 </div>
                 
                 {/* Thumbnail Selection in Lightbox */}
                 <div className="flex gap-4 overflow-x-auto pb-4 max-w-full no-scrollbar bg-black/40 backdrop-blur-2xl p-4 rounded-[2rem] border border-white/5">
                   {product.images.map((img, idx) => (
                     <button
                        key={idx}
                        onClick={() => setCurrentImageIndex(idx)}
                        className={`w-20 h-28 rounded-2xl overflow-hidden flex-shrink-0 border-2 transition-all duration-700 relative ${currentImageIndex === idx ? 'border-pink-500 scale-110 shadow-[0_0_40px_rgba(236,72,153,0.4)]' : 'border-white/10 opacity-30 hover:opacity-100 hover:scale-105'}`}
                     >
                        <img src={img} className="w-full h-full object-cover" alt="" />
                        {currentImageIndex === idx && <div className="absolute inset-0 bg-pink-500/20" />}
                     </button>
                   ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Buyer Diary / Feedbacks Overlay */}
      {showReviews && (
        <div className="absolute inset-0 bg-white z-[60] flex flex-col animate-in slide-in-from-bottom-8 duration-700">
          <div className="flex justify-between items-center p-8 border-b border-stone-100 bg-stone-50/50">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-pink-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-pink-100">
                <MessageCircle size={24} />
              </div>
              <div className="flex flex-col">
                 <h4 className="text-[12px] font-black uppercase tracking-widest text-stone-900 leading-none">Buyer Diary</h4>
                 <span className="text-[10px] text-stone-400 font-bold uppercase mt-1.5 tracking-tighter">Verified Client Feedback</span>
              </div>
            </div>
            <button 
              onClick={() => setShowReviews(false)} 
              className="p-3 bg-white text-stone-400 hover:text-pink-600 hover:scale-110 rounded-full transition-all border border-stone-100"
            >
              <X size={24} />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-10 space-y-10 scroll-smooth">
            {product.reviews.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-20">
                 <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center mb-8 border border-stone-100">
                    <Sparkles size={32} className="text-stone-200" />
                 </div>
                 <p className="text-[11px] text-stone-400 font-black uppercase tracking-[0.3em] max-w-[200px]">Be the first to share your Tanish look</p>
              </div>
            ) : (
              product.reviews.map(review => (
                <div key={review.id} className="space-y-4 animate-in fade-in slide-in-from-left-4 duration-500">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-pink-50 rounded-full flex items-center justify-center text-pink-600 font-black text-xs border border-pink-100">
                        {review.name[0]}
                      </div>
                      <div className="flex flex-col">
                         <span className="text-[12px] font-black text-stone-900 uppercase tracking-tight">{review.name}</span>
                         <span className="text-[10px] text-stone-300 uppercase font-black tracking-tighter">{review.date}</span>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={12} className={`${i < review.rating ? 'text-amber-500 fill-amber-500' : 'text-stone-100 fill-stone-100'}`} />
                      ))}
                    </div>
                  </div>
                  <div className="bg-stone-50 p-6 rounded-[2rem] border border-stone-100 relative group/quote">
                    <p className="text-sm text-stone-700 leading-relaxed font-light italic">"{review.comment}"</p>
                    <div className="absolute top-0 right-8 -translate-y-1/2 bg-white px-3 py-1 border border-stone-100 rounded-full text-[8px] font-black text-stone-300 uppercase tracking-[0.3em]">Verified Purchase</div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Review Submission Form */}
          <div className="p-10 border-t border-stone-100 bg-white shadow-[0_-20px_50px_-20px_rgba(0,0,0,0.1)]">
            <form onSubmit={handleSubmitReview} className="space-y-5">
              <div className="grid grid-cols-1 gap-4">
                <input 
                  type="text" 
                  placeholder="Your Name"
                  value={newReviewName}
                  onChange={(e) => setNewReviewName(e.target.value)}
                  required
                  className="w-full bg-stone-50 p-5 border border-stone-200 text-[11px] font-black uppercase tracking-widest rounded-2xl focus:bg-white focus:ring-2 focus:ring-pink-500 outline-none transition-all"
                />
                <textarea 
                  placeholder="Tell us how much you loved Munna's stitching..."
                  value={newReviewComment}
                  onChange={(e) => setNewReviewComment(e.target.value)}
                  required
                  rows={2}
                  className="w-full bg-stone-50 p-5 border border-stone-200 text-sm font-medium rounded-2xl focus:bg-white focus:ring-2 focus:ring-pink-500 outline-none resize-none transition-all"
                />
              </div>
              <button 
                type="submit" 
                className="w-full bg-stone-900 text-white py-5 text-[11px] tracking-[0.2em] uppercase font-black hover:bg-pink-600 transition-all rounded-2xl shadow-2xl active:scale-95"
              >
                Share Feedback
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductCard;
