
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, Loader2, Cat } from 'lucide-react';
import { getStylingAdvice } from '../geminiService';
import { PRODUCTS } from '../constants';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const AIStylist: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: "Meow-namaste! 🐾 I am Coco, your purr-sonal fashion cat! Looking for a stunning Punjabi suit or want to book a stitching session? Tell me in any language, I'm all ears! Purrr..." }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    const response = await getStylingAdvice(userMessage, PRODUCTS);
    
    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setIsLoading(false);
  };

  return (
    <div className="max-w-3xl mx-auto h-[70vh] flex flex-col bg-white border border-pink-100 rounded-2xl shadow-xl shadow-pink-50 overflow-hidden mt-8">
      <div className="p-6 border-b border-pink-100 bg-gradient-to-r from-pink-50 to-white flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-full bg-pink-600 flex items-center justify-center text-white border-4 border-white shadow-md">
            <Cat size={24} />
          </div>
          <div>
            <h3 className="font-bold text-stone-900 serif text-lg">Coco Assistant</h3>
            <p className="text-[10px] uppercase tracking-widest text-pink-500 font-bold">Feline Fashion Expert • Online</p>
          </div>
        </div>
        <div className="hidden sm:block">
          <span className="text-[10px] bg-pink-100 text-pink-700 px-3 py-1 rounded-full font-bold uppercase tracking-tighter">
            Multilingual Indian Cat 🇮🇳
          </span>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth bg-[#fffafb]">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] flex items-start space-x-3 ${m.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center shadow-sm ${m.role === 'user' ? 'bg-stone-200 text-stone-600' : 'bg-pink-100 text-pink-600'}`}>
                {m.role === 'user' ? <User size={14} /> : <Cat size={14} />}
              </div>
              <div className={`p-4 rounded-2xl text-sm leading-relaxed ${m.role === 'user' ? 'bg-stone-900 text-white rounded-tr-none' : 'bg-white text-stone-800 border border-pink-50 shadow-sm rounded-tl-none'}`}>
                <div className="prose prose-sm prose-stone">
                  {m.content.split('\n').map((line, idx) => (
                    <p key={idx} className="mb-2 last:mb-0">{line}</p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center">
                <Loader2 size={14} className="animate-spin" />
              </div>
              <div className="p-4 rounded-2xl bg-white border border-pink-50 text-pink-400 italic text-[10px] tracking-widest uppercase font-bold shadow-sm">
                Coco is grooming her whiskers... (Thinking)
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-white border-t border-pink-50">
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSend(); }}
          className="relative flex items-center gap-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Ask Coco: 'Red suit dikhao' or 'Book session'..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="w-full p-4 pr-12 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 text-sm font-light bg-pink-50/30"
            />
            <button 
              type="submit"
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-pink-400 hover:text-pink-600 transition-colors"
            >
              <Send size={20} />
            </button>
          </div>
        </form>
        <p className="text-[8px] text-stone-400 mt-2 text-center uppercase tracking-[0.2em]">Meow! Coco can talk in Hindi, Punjabi, and more!</p>
      </div>
    </div>
  );
};

export default AIStylist;
