
import React from 'react';
import { Cat } from 'lucide-react';

interface FloatingCocoProps {
  onClick: () => void;
}

const FloatingCoco: React.FC<FloatingCocoProps> = ({ onClick }) => {
  return (
    <button 
      onClick={onClick}
      className="fixed bottom-6 right-6 z-[90] group flex items-center gap-3"
      aria-label="Ask Coco"
    >
      <div className="bg-white px-4 py-2 rounded-full shadow-lg border border-pink-100 opacity-0 group-hover:opacity-100 transition-all duration-300 -translate-x-2 group-hover:translate-x-0 hidden md:block">
        <p className="text-[10px] font-bold text-pink-600 uppercase tracking-widest">Ask Coco Meow!</p>
      </div>
      <div className="relative">
        <div className="absolute inset-0 bg-pink-500 rounded-full animate-ping opacity-25"></div>
        <div className="relative w-14 h-14 bg-pink-600 text-white rounded-full flex items-center justify-center shadow-xl hover:scale-110 hover:bg-pink-700 transition-all">
          <Cat size={28} />
        </div>
      </div>
    </button>
  );
};

export default FloatingCoco;
