
import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, CreditCard, Loader2, Calendar, Smartphone, QrCode, Scissors, Wallet, ReceiptText } from 'lucide-react';
import { CartItem } from '../types';
import PaymentQR from './PaymentQR';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemove: (uniqueId: string) => void;
  onUpdateQuantity: (uniqueId: string, delta: number) => void;
  onUpdateDate: (uniqueId: string, date: string) => void;
  onUpdateLaces: (uniqueId: string, meters: number) => void;
  onCheckout: (isAdvance: boolean) => void;
  isProcessing: boolean;
}

const Cart: React.FC<CartProps> = ({ 
  isOpen, 
  onClose, 
  items, 
  onRemove, 
  onUpdateQuantity, 
  onUpdateDate, 
  onUpdateLaces, 
  onCheckout, 
  isProcessing 
}) => {
  const [showQR, setShowQR] = useState(false);
  const [isAdvancePayment, setIsAdvancePayment] = useState(false);
  
  const calculateItemTotal = (item: CartItem) => {
    const baseTotal = item.price * item.quantity;
    const laceTotal = (item.laceMeters || 0) * (item.selectedLace?.price || 0);
    return baseTotal + laceTotal;
  };

  const totalValue = items.reduce((acc, item) => acc + calculateItemTotal(item), 0);
  const savings = items.reduce((acc, item) => acc + ((item.originalPrice - item.price) * item.quantity), 0);
  const totalQuantity = items.reduce((acc, item) => acc + item.quantity, 0);

  const amountToPayNow = isAdvancePayment ? Math.ceil(totalValue / 2) : totalValue;

  const handleFinalCheckout = () => {
    onCheckout(isAdvancePayment);
    setShowQR(false);
  };

  return (
    <div className={`fixed inset-0 z-[100] transition-opacity duration-300 ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
      <div className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm" onClick={onClose} />
      
      <div className={`absolute top-0 right-0 w-full max-md:max-w-full max-w-md h-full bg-white shadow-2xl transition-transform duration-300 ease-in-out transform flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-6 border-b border-stone-100 flex justify-between items-center bg-stone-50">
          <div className="flex items-center gap-3">
            <ShoppingBag className="text-pink-600" size={20} />
            <h2 className="text-lg font-bold tracking-widest uppercase text-stone-900">{showQR ? 'Scan to Pay' : `Your Cart (${totalQuantity})`}</h2>
          </div>
          <button onClick={onClose} className="p-2 text-stone-400 hover:text-pink-600 transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {showQR ? (
            <div className="flex flex-col items-center space-y-8 animate-in slide-in-from-right duration-300">
               <div className="text-center space-y-2 px-4">
                 <h3 className="text-xl font-light serif italic text-stone-900">Final Order Payment</h3>
                 <p className="text-[10px] text-stone-500 uppercase tracking-widest">
                   {isAdvancePayment 
                    ? `Transfer ₹${amountToPayNow.toLocaleString('en-IN')} (50% Advance) to Samsul Hoda (Munna)` 
                    : `Transfer ₹${amountToPayNow.toLocaleString('en-IN')} (Full Amount) to Samsul Hoda (Munna)`}
                 </p>
               </div>
               
               {/* Updated PaymentQR with dynamic amount */}
               <PaymentQR amount={amountToPayNow} />
               
               <div className="w-full bg-stone-50 p-6 rounded-3xl border border-stone-100 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Payment Mode</span>
                    <span className="text-[10px] font-black text-pink-600 uppercase tracking-widest bg-pink-50 px-3 py-1 rounded-full">{isAdvancePayment ? '50% Advance' : 'Full Payment'}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-stone-200/50">
                    <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Amount Payable</span>
                    <span className="text-2xl font-black text-stone-900">₹{amountToPayNow.toLocaleString('en-IN')}</span>
                  </div>
               </div>

               <button 
                 onClick={() => setShowQR(false)}
                 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest hover:text-pink-600 border-b border-dashed border-stone-200 transition-colors"
               >
                 Review Order & Options
               </button>
            </div>
          ) : (
            items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center">
                  <ShoppingBag size={32} className="text-stone-200" />
                </div>
                <div className="space-y-2">
                  <p className="text-stone-900 font-serif italic text-lg">Your bag is empty</p>
                  <p className="text-stone-400 text-xs uppercase tracking-widest">Find your perfect Punjabi silhouette today.</p>
                </div>
                <button onClick={onClose} className="bg-stone-900 text-white px-10 py-4 text-[10px] font-bold uppercase tracking-widest hover:bg-pink-600 transition-colors">Return to Shop</button>
              </div>
            ) : (
              items.map((item, index) => {
                const cartId = item.id + '-' + index;
                return (
                  <div key={cartId} className="flex flex-col gap-4 border-b border-stone-100 pb-6 last:border-0">
                    <div className="flex gap-4">
                      <div className="w-24 h-32 bg-stone-100 rounded-lg overflow-hidden flex-shrink-0 shadow-sm">
                        <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex justify-between items-start">
                          <h3 className="text-[11px] font-bold uppercase tracking-tight text-stone-900 leading-tight pr-4">{item.name}</h3>
                          <button onClick={() => onRemove(cartId)} className="text-stone-300 hover:text-red-500 transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </div>
                        
                        <div className="flex items-center gap-4 mt-2">
                          <div className="flex items-center border border-stone-200 rounded">
                            <button onClick={() => onUpdateQuantity(cartId, -1)} className="px-2 py-1 text-stone-400 hover:text-stone-900">-</button>
                            <span className="px-2 py-1 text-xs min-w-[24px] text-center font-bold">{item.quantity}</span>
                            <button onClick={() => onUpdateQuantity(cartId, 1)} className="px-2 py-1 text-stone-400 hover:text-stone-900">+</button>
                          </div>
                          <span className="text-xs font-black text-stone-900">₹{item.price * item.quantity}</span>
                        </div>

                        {/* Delivery Date Selection */}
                        <div className="mt-3 bg-stone-50 p-2.5 rounded-lg border border-stone-100">
                          <label className="flex items-center gap-2 text-[9px] font-black text-stone-400 uppercase mb-1.5 tracking-wider">
                            <Calendar size={10} className="text-pink-500" /> Stitching Target Date:
                          </label>
                          <input 
                            type="date" 
                            value={item.requestedDate || ''}
                            onChange={(e) => onUpdateDate(cartId, e.target.value)}
                            className="w-full bg-white border border-stone-200 p-2 text-[10px] font-bold rounded focus:ring-1 focus:ring-pink-500 outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Lace Details display */}
                    {item.selectedLace && (
                      <div className="bg-pink-50/40 p-3.5 rounded-xl border border-pink-100/50 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Scissors size={12} className="text-pink-600" />
                            <span className="text-[10px] font-black uppercase tracking-widest text-pink-800">{item.selectedLace.name}</span>
                          </div>
                          <span className="text-[9px] font-black text-pink-400">₹{item.selectedLace.price}/mtr</span>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <input 
                                type="number" 
                                min="0"
                                step="0.5"
                                value={item.laceMeters || 0}
                                onChange={(e) => onUpdateLaces(cartId, parseFloat(e.target.value) || 0)}
                                className="w-16 bg-white border border-stone-200 p-1.5 text-[10px] font-black rounded focus:ring-1 focus:ring-pink-500 outline-none"
                              />
                              <span className="text-[10px] font-black text-stone-400 uppercase tracking-tighter">Meters</span>
                            </div>
                          </div>
                          <div className="text-right flex flex-col">
                            <span className="text-[8px] font-bold text-stone-400 uppercase tracking-widest">Lace Subtotal</span>
                            <span className="text-xs font-black text-pink-700">+ ₹{((item.laceMeters || 0) * (item.selectedLace.price || 0)).toFixed(0)}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )
          )}
        </div>

        {items.length > 0 && (
          <div className="p-6 border-t border-stone-100 bg-white space-y-5 shadow-[0_-10px_20px_-10px_rgba(0,0,0,0.05)]">
            {/* Payment Options Selection */}
            {!showQR && (
              <div className="space-y-3 mb-4">
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest text-center">Payment Schedule</p>
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => setIsAdvancePayment(false)}
                    className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${!isAdvancePayment ? 'border-pink-600 bg-pink-50 ring-4 ring-pink-50' : 'border-stone-100 bg-white grayscale opacity-60'}`}
                  >
                    <ReceiptText size={16} className={!isAdvancePayment ? 'text-pink-600' : 'text-stone-300'} />
                    <span className="text-[9px] font-black uppercase tracking-tighter">Full Payment</span>
                    <span className="text-xs font-black text-stone-900">₹{totalValue}</span>
                  </button>
                  <button 
                    onClick={() => setIsAdvancePayment(true)}
                    className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${isAdvancePayment ? 'border-pink-600 bg-pink-50 ring-4 ring-pink-50' : 'border-stone-100 bg-white grayscale opacity-60'}`}
                  >
                    <Wallet size={16} className={isAdvancePayment ? 'text-pink-600' : 'text-stone-300'} />
                    <span className="text-[9px] font-black uppercase tracking-tighter">50% Advance</span>
                    <span className="text-xs font-black text-stone-900">₹{Math.ceil(totalValue / 2)}</span>
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-2.5">
              <div className="flex justify-between text-[11px] text-stone-500 uppercase tracking-widest">
                <span>Total Items</span>
                <span>₹{items.reduce((acc, i) => acc + (i.price * i.quantity), 0)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-pink-600 uppercase tracking-widest">
                <span>Total Custom Laces</span>
                <span>₹{items.reduce((acc, i) => acc + ((i.laceMeters || 0) * (i.selectedLace?.price || 0)), 0).toFixed(0)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-green-600 uppercase tracking-widest font-black">
                <span>Coco's App Discount</span>
                <span>- ₹{savings}</span>
              </div>
              <div className="flex justify-between text-xl font-bold text-stone-900 border-t border-stone-100 pt-4 mt-3">
                <div className="flex flex-col">
                  <span className="serif italic">Amount to Pay Now</span>
                  {isAdvancePayment && <span className="text-[9px] font-black text-pink-500 uppercase tracking-widest">50% Advance Selected</span>}
                </div>
                <span className="text-pink-700">₹{amountToPayNow.toFixed(0)}</span>
              </div>
            </div>

            {showQR ? (
              <button 
                onClick={handleFinalCheckout}
                disabled={isProcessing}
                className="w-full bg-green-600 text-white py-4 text-xs font-black tracking-[0.2em] uppercase rounded-lg hover:bg-green-700 transition-all disabled:opacity-50 flex items-center justify-center gap-3 shadow-lg shadow-green-100"
              >
                {isProcessing ? <><Loader2 size={16} className="animate-spin" /> Verifying Payment...</> : <><Smartphone size={16} /> I've Paid, Notify Munna</>}
              </button>
            ) : (
              <button 
                onClick={() => setShowQR(true)}
                className="w-full bg-stone-950 text-white py-4 text-xs font-black tracking-[0.2em] uppercase rounded-lg hover:bg-pink-700 transition-all flex items-center justify-center gap-3 shadow-xl"
              >
                <QrCode size={16} /> Secure UPI Payment
              </button>
            )}
            
            <p className="text-[8px] text-stone-400 text-center uppercase tracking-widest leading-relaxed font-bold">
              Tailoring by Samsul Hoda (Munna) • Dakoha, Jalandhar<br/>
              UPI ID: shams82644153@barodampay
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;
