
import React, { useState } from 'react';
import { Ruler, Save, CheckCircle } from 'lucide-react';

const MeasurementForm: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center space-y-4 animate-in fade-in duration-500">
        <div className="w-16 h-16 bg-pink-50 rounded-full flex items-center justify-center text-pink-600 mb-4">
          <CheckCircle size={40} />
        </div>
        <h2 className="text-2xl font-light italic">Measurements Saved!</h2>
        <p className="text-stone-500 max-w-sm">Your custom measurements have been linked to your profile. We will use these for your next order.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-8">
      <div className="bg-white p-8 border border-stone-200 rounded-sm shadow-sm">
        <div className="flex items-center gap-3 mb-8 pb-4 border-b border-stone-100">
          <Ruler className="text-pink-600" />
          <h2 className="text-2xl font-light serif italic">Custom Measurement Profile</h2>
        </div>
        
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-stone-400">Upper Body (Inches)</h3>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Bust/Chest</label>
              <input type="text" placeholder="e.g. 36" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" required />
            </div>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Waist</label>
              <input type="text" placeholder="e.g. 30" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" required />
            </div>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Sleeve Length</label>
              <input type="text" placeholder="e.g. 15" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Neck Depth (Front)</label>
              <input type="text" placeholder="e.g. 7" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-stone-400">Lower Body (Inches)</h3>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Hips</label>
              <input type="text" placeholder="e.g. 38" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" required />
            </div>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Suit/Kameez Length</label>
              <input type="text" placeholder="e.g. 42" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" required />
            </div>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Shoulder Width</label>
              <input type="text" placeholder="e.g. 14" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" />
            </div>
            <div>
              <label className="block text-[10px] uppercase text-stone-500 mb-1">Neck Depth (Back)</label>
              <input type="text" placeholder="e.g. 8" className="w-full p-2 border border-stone-200 text-sm focus:ring-1 focus:ring-pink-500 outline-none" />
            </div>
          </div>

          <div className="md:col-span-2 pt-6">
            <button type="submit" className="w-full bg-stone-900 text-white py-3 text-xs tracking-widest uppercase hover:bg-pink-700 transition-colors flex items-center justify-center gap-2">
              <Save size={16} /> Save My Measurements
            </button>
            <p className="text-[10px] text-stone-400 mt-2 text-center italic">Measurements are private and only used for your custom orders at Tanish Boutique.</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MeasurementForm;
