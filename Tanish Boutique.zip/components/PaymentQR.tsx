
import React, { useState } from 'react';
import { Smartphone, ShieldCheck, ArrowRight, Check, Copy, ExternalLink } from 'lucide-react';

interface PaymentQRProps {
  amount?: number;
  orderId?: string;
}

const PaymentQR: React.FC<PaymentQRProps> = ({ amount, orderId }) => {
  const upiId = "shams82644153@barodampay";
  const payeeName = "SHAMSUL HODA";
  const transactionNote = orderId ? `Order ${orderId}` : "Tanish Boutique Payment";
  const [copied, setCopied] = useState(false);
  
  // Construct dynamic UPI URL with amount if provided
  // Standard UPI Intent: upi://pay?pa=address&pn=name&am=amount&cu=INR&tn=note
  const upiUrl = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(payeeName)}${amount ? `&am=${amount}` : ''}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=350x350&data=${encodeURIComponent(upiUrl)}`;

  const handleMobilePay = () => {
    // Attempt to open the UPI deep link
    window.location.href = upiUrl;
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const supportedApps = [
    { src: "https://img.icons8.com/color/48/google-pay-india.png", label: "GPay" },
    { src: "https://img.icons8.com/color/48/phonepe.png", label: "PhonePe" },
    { src: "https://img.icons8.com/color/48/paytm.png", label: "Paytm" },
    { src: "https://img.icons8.com/color/48/bhim.png", label: "BHIM" },
    { src: "https://img.icons8.com/color/48/amazon-pay.png", label: "Amazon" },
    { src: "https://img.icons8.com/color/48/whatsapp.png", label: "WhatsApp" },
    { src: "https://img.icons8.com/color/48/mobikwik.png", label: "MobiKwik" },
    { src: "https://img.icons8.com/external-tal-revivo-shadow-tal-revivo/24/external-payzapp-a-complete-payment-solution-for-all-your-needs-logo-shadow-tal-revivo.png", label: "PayZapp" }
  ];

  return (
    <div className="w-full max-w-[400px] mx-auto bg-white rounded-[2.5rem] overflow-hidden shadow-[0_20px_50px_-15px_rgba(0,0,0,0.15)] border border-pink-50 relative animate-in zoom-in-95 duration-500">
      {/* Premium Header */}
      <div className="bg-gradient-to-br from-pink-600 to-pink-700 p-7 text-white text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
        <div className="relative z-10 flex flex-col items-center">
          <div className="bg-white/20 backdrop-blur-md px-4 py-1 rounded-full border border-white/20 mb-3">
            <span className="text-[9px] font-black tracking-[0.3em] uppercase">Unified Payments Interface</span>
          </div>
          <h2 className="text-2xl font-black italic serif tracking-tight">Tanish Boutique</h2>
          <p className="text-[10px] opacity-70 font-bold uppercase tracking-widest mt-1">Direct Merchant Terminal</p>
        </div>
      </div>

      <div className="p-8 bg-white flex flex-col items-center">
        {/* Payee Info */}
        <div className="mb-8 text-center w-full">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="h-[1px] flex-1 bg-stone-100"></div>
            <span className="text-stone-300 text-[8px] font-black uppercase tracking-[0.4em]">Verified Recipient</span>
            <div className="h-[1px] flex-1 bg-stone-100"></div>
          </div>
          <h3 className="text-stone-900 text-xl font-black uppercase tracking-tighter">{payeeName}</h3>
          
          {amount && (
            <div className="mt-4 p-4 bg-pink-50/50 rounded-3xl border border-pink-100 flex flex-col items-center relative group">
               <span className="text-[9px] font-black text-pink-400 uppercase tracking-widest mb-1">Total to Pay</span>
               <div className="flex items-baseline gap-1">
                 <span className="text-sm font-black text-pink-600">₹</span>
                 <span className="text-3xl font-black text-pink-600">{amount.toLocaleString('en-IN')}</span>
               </div>
            </div>
          )}
        </div>
        
        {/* Dynamic QR Display */}
        <div 
          className="relative group cursor-pointer mb-10" 
          onClick={handleMobilePay}
          title="Scan to pay or tap to open app"
        >
          <div className="w-64 h-64 bg-white p-5 rounded-[2.5rem] shadow-[0_15px_35px_-10px_rgba(219,39,119,0.15)] border-2 border-pink-50 relative overflow-hidden transition-all duration-500 group-hover:shadow-2xl group-hover:scale-[1.03] active:scale-95">
            <img 
              src={qrCodeUrl} 
              alt="UPI QR Code" 
              className="w-full h-full object-contain opacity-90 transition-transform duration-700 group-hover:rotate-2"
            />
            {/* Boutique Logo in QR Center */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-16 h-16 bg-white border-2 border-pink-600 rounded-[1.25rem] flex flex-col items-center justify-center shadow-xl">
                 <span className="text-pink-600 font-black text-sm leading-none">TANISH</span>
                 <span className="text-pink-300 font-black text-[7px] tracking-tighter leading-none mt-0.5">EST. 1994</span>
              </div>
            </div>
          </div>
          
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-stone-900 text-white px-6 py-2.5 rounded-full shadow-2xl whitespace-nowrap flex items-center gap-2 animate-bounce hover:bg-pink-600 transition-colors">
            <Smartphone size={14} />
            <p className="text-[11px] font-black uppercase tracking-widest">Tap to Open UPI App</p>
          </div>
        </div>

        {/* All UPI Apps Selection Grid */}
        <div className="w-full space-y-6">
          <div className="flex items-center gap-3">
            <div className="h-[1px] flex-1 bg-stone-100"></div>
            <span className="text-[9px] font-black text-stone-300 uppercase tracking-[0.3em]">Support for all apps</span>
            <div className="h-[1px] flex-1 bg-stone-100"></div>
          </div>
          
          {/* Functional App Grid - 4x2 */}
          <div className="grid grid-cols-4 gap-4">
            {supportedApps.map((app, idx) => (
              <button 
                key={idx} 
                onClick={handleMobilePay}
                className="flex flex-col items-center group/app transition-all active:scale-90"
              >
                <div className="w-14 h-14 bg-stone-50 rounded-2xl shadow-sm flex items-center justify-center p-3 border border-stone-100 group-hover/app:border-pink-200 group-hover/app:bg-white group-hover/app:shadow-lg group-hover/app:-translate-y-1 transition-all duration-300">
                  <img src={app.src} alt={app.label} className="w-full h-full object-contain" />
                </div>
                <span className="mt-2 text-[9px] font-black text-stone-400 uppercase tracking-tighter group-hover/app:text-pink-600 transition-colors">{app.label}</span>
              </button>
            ))}
          </div>

          <div className="space-y-3">
            <button 
              onClick={handleMobilePay}
              className="w-full bg-stone-900 text-white py-5 rounded-2xl text-[12px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 hover:bg-pink-600 transition-all shadow-xl shadow-stone-200 active:scale-95 group"
            >
              <ExternalLink size={18} className="group-hover:rotate-12 transition-transform" />
              Pay via Preferred App
            </button>
            
            {/* Copy UPI ID Helper */}
            <button 
              onClick={handleCopyId}
              className="w-full bg-stone-50 text-stone-600 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest border border-stone-100 hover:bg-white hover:border-pink-200 flex items-center justify-center gap-2 transition-all"
            >
              {copied ? (
                <><Check size={14} className="text-green-500" /> Copied UPI ID!</>
              ) : (
                <><Copy size={14} /> Copy VPA: {upiId}</>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Security Verification Footer */}
      <div className="bg-stone-50 py-6 border-t border-stone-100 flex items-center justify-center gap-6">
        <div className="flex items-center gap-2">
          <ShieldCheck size={18} className="text-green-600" />
          <div className="flex flex-col">
            <span className="text-[10px] font-black uppercase text-stone-700 tracking-widest leading-none">Secure Payment</span>
            <span className="text-[8px] font-bold text-stone-400 uppercase tracking-tighter mt-0.5">Encrypted Intent Gateway</span>
          </div>
        </div>
        <div className="h-8 w-[1px] bg-stone-200"></div>
        <div className="flex items-center gap-2">
           <img src="https://img.icons8.com/color/48/bhim.png" className="w-6 h-6 grayscale opacity-50" alt="BHIM" />
           <span className="text-[8px] font-black text-stone-400 uppercase tracking-widest">BHIM • UPI</span>
        </div>
      </div>
    </div>
  );
};

export default PaymentQR;
